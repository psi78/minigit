#include <iostream>
#include <fstream>
#include <filesystem>
#include <sstream>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <openssl/sha.h>
#include <iomanip>
#include <ctime>
#include <queue>
#include <unordered_set>

namespace fs = std::filesystem;

struct CommitObject {
    std::string hash;
    std::string tree_hash;
    std::string message;
    std::string author;
    std::string committer;
    std::string timestamp;
    std::vector<std::string> parent_hashes;
};

struct IndexEntry {
    std::string filePath;
    std::string blobHash;
};

std::map<fs::path, std::string> staging_area;
std::string current_branch = "main";

std::string computeHash(const std::string& content) {
    unsigned char hash[SHA_DIGEST_LENGTH];
    SHA1(reinterpret_cast<const unsigned char*>(content.c_str()),
          content.size(), hash);

    std::stringstream ss;
    for (int i = 0; i < SHA_DIGEST_LENGTH; i++) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(hash[i]);
    }
    return ss.str();
}

void storeObject(const std::string& hash, const std::string& content) {
    fs::path objectPath = ".minigit/objects/" + hash.substr(0, 2) + "/" + hash.substr(2);
    fs::create_directories(objectPath.parent_path());
    std::ofstream objectFile(objectPath);
    if (!objectFile.is_open()) {
        throw std::runtime_error("Could not open object file for writing: " + objectPath.string());
    }
    objectFile << content;
}

std::string readObject(const std::string& hash) {
    fs::path objectPath = ".minigit/objects/" + hash.substr(0, 2) + "/" + hash.substr(2);
    std::ifstream objectFile(objectPath);
    if (!objectFile.is_open()) {
        throw std::runtime_error("Could not open object file for reading: " + objectPath.string());
    }
    std::stringstream ss;
    ss << objectFile.rdbuf();
    return ss.str();
}

std::vector<std::string> splitLines(const std::string& content) {
    std::vector<std::string> lines;
    std::istringstream stream(content);
    std::string line;
    while (std::getline(stream, line)) {
        lines.push_back(line);
    }
    return lines;
}

std::string readFile(const fs::path& filePath) {
    std::ifstream file(filePath);
    if (!file.is_open()) {
        throw std::runtime_error("Could not open file for reading: " + filePath.string());
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

void writeFile(const fs::path& filePath, const std::string& content) {
    // Only create directories if the file path has a parent directory
    // If filePath is just "file.txt", its parent_path() is empty.
    if (!filePath.parent_path().empty()) {
        fs::create_directories(filePath.parent_path());
    }
    std::ofstream file(filePath);
    if (!file.is_open()) {
        throw std::runtime_error("Could not open file for writing: " + filePath.string());
    }
    file << content;
}

void readIndex() {
    staging_area.clear();
    std::ifstream indexFile(".minigit/index");
    if (!indexFile.is_open()) return;

    std::string line;
    while (std::getline(indexFile, line)) {
        size_t spacePos = line.find(' ');
        if (spacePos != std::string::npos) {
            std::string filePath = line.substr(0, spacePos);
            std::string blobHash = line.substr(spacePos + 1);
            staging_area[filePath] = blobHash;
        }
    }
}

void updateIndex() {
    std::ofstream indexFile(".minigit/index", std::ios::trunc);
    if (!indexFile.is_open()) {
        throw std::runtime_error("Could not open .minigit/index for writing.");
    }
    for (const auto& entry : staging_area) {
        indexFile << entry.first.string() << " " << entry.second << "\n";
    }
}

std::set<fs::path> getPaths(const std::map<fs::path, std::string>& filesMap) {
    std::set<fs::path> paths;
    for (const auto& pair : filesMap) {
        paths.insert(pair.first);
    }
    return paths;
}

void cleanWorkingDirectory(const std::set<fs::path>& keepPaths) {
    std::vector<fs::path> filesToDelete;
    for (const auto& entry : fs::recursive_directory_iterator(fs::current_path())) {
        // Exclude the .minigit directory itself
        if (entry.path().string().find(".minigit") != std::string::npos) {
            continue;
        }
        // Explicitly skip the executable file if it's the current running one
        // Checks for both "minigit" and "minigit.exe" for cross-platform compatibility
        if (entry.is_regular_file() && 
            (entry.path().filename() == "minigit" || entry.path().filename() == "minigit.exe")) {
            continue; // Do not delete the running executable
        }
        // If it's a regular file and not in the keepPaths, mark for deletion
        if (entry.is_regular_file() && keepPaths.find(entry.path()) == keepPaths.end()) {
            filesToDelete.push_back(entry.path());
        }
    }

    for (const auto& path : filesToDelete) {
        try {
            fs::remove(path);
        } catch (const fs::filesystem_error& e) {
            std::cerr << "Warning: Could not remove file " << path.string() << ": " << e.what() << std::endl;
        }
    }

    std::vector<fs::path> dirs;
    for (const auto& entry : fs::recursive_directory_iterator(fs::current_path())) {
        if (entry.path().string().find(".minigit") != std::string::npos) {
            continue;
        }
        if (entry.is_directory()) {
            dirs.push_back(entry.path());
        }
    }
    std::sort(dirs.begin(), dirs.end(), [](const fs::path& a, const fs::path& b) {
        return a.string().length() > b.string().length();
    });

    for (const auto& dir : dirs) {
        try {
            if (fs::is_empty(dir)) {
                fs::remove(dir);
            }
        } catch (const fs::filesystem_error& e) {
        }
    }
}

void restoreFiles(const std::map<fs::path, std::string>& filesToRestore) {
    for (const auto& [path, hash] : filesToRestore) {
        std::string content = readObject(hash);
        writeFile(path, content);
    }
}

std::map<fs::path, std::string> getTreeFiles(const std::string& treeHash, const fs::path& basePath = "") {
    std::map<fs::path, std::string> files;
    std::string treeContent = readObject(treeHash);
    std::istringstream contentStream(treeContent);
    std::string line;

    while (std::getline(contentStream, line)) {
        size_t firstSpace = line.find(' ');
        size_t secondSpace = line.find(' ', firstSpace + 1);
        if (firstSpace == std::string::npos || secondSpace == std::string::npos) continue;

        std::string type = line.substr(firstSpace + 1, secondSpace - firstSpace - 1);
        std::string hash = line.substr(secondSpace + 1, 40);
        std::string name = line.substr(secondSpace + 42);

        fs::path fullPath = basePath / name;

        if (type == "blob") {
            files[fullPath] = hash;
        } else if (type == "tree") {
            auto subtreeFiles = getTreeFiles(hash, fullPath);
            files.insert(subtreeFiles.begin(), subtreeFiles.end());
        }
    }
    return files;
}

std::string createTreeFromFiles(const std::map<fs::path, std::string>& files) {
    std::map<std::string, std::map<std::string, std::string>> dirEntries;
    
    for (const auto& [path, hash] : files) {
        fs::path dir = path.parent_path();
        if (dir.empty()) dir = ".";
        dirEntries[dir.string()][path.filename().string()] = hash;
    }
    
    std::vector<std::string> dirs;
    for (const auto& [dir, _] : dirEntries) {
        dirs.push_back(dir);
    }
    std::sort(dirs.begin(), dirs.end(), [](const auto& a, const auto& b) {
        return a.length() > b.length();
    });
    
    std::map<std::string, std::string> treeHashes;
    
    for (const auto& dir : dirs) {
        std::stringstream treeContent;
        
        for (const auto& [name, hash] : dirEntries[dir]) {
            treeContent << "100644 blob " << hash << " " << name << "\n";
        }
        
        for (const auto& [subdir, subhash] : treeHashes) {
            if (fs::path(subdir).parent_path().string() == dir) {
                treeContent << "40000 tree " << subhash << " " << fs::path(subdir).filename().string() << "\n";
            }
        }
        
        std::string treeStr = treeContent.str();
        std::string treeHash = computeHash(treeStr);
        storeObject(treeHash, treeStr);
        treeHashes[dir] = treeHash;
    }
    
    if (treeHashes.count(".")) {
        return treeHashes["."];
    }
    return "";
}

CommitObject parseCommitObject(const std::string& commitHash) {
    CommitObject commit;
    commit.hash = commitHash;
    std::string content = readObject(commitHash);
    
    std::istringstream ss(content);
    std::string line;

    while (std::getline(ss, line) && !line.empty()) {
        if (line.rfind("tree ", 0) == 0) {
            commit.tree_hash = line.substr(5, 40);
        } else if (line.rfind("parent ", 0) == 0) {
            commit.parent_hashes.push_back(line.substr(7, 40));
        } else if (line.rfind("author ", 0) == 0) {
            size_t email_end = line.find_last_of('>');
            if (email_end != std::string::npos) {
                commit.author = line.substr(7, email_end - 6);
                size_t timestamp_start = line.find_first_not_of(' ', email_end + 1);
                if (timestamp_start != std::string::npos) {
                    commit.timestamp = line.substr(timestamp_start);
                }
            }
        } else if (line.rfind("committer ", 0) == 0) {
            size_t email_end = line.find_last_of('>');
            if (email_end != std::string::npos) {
                commit.committer = line.substr(10, email_end - 9);
                size_t timestamp_start = line.find_first_not_of(' ', email_end + 1);
                if (timestamp_start != std::string::npos) {
                    commit.timestamp = line.substr(timestamp_start);
                }
            }
        }
    }

    if (commit.timestamp.empty()) {
        commit.timestamp = std::to_string(std::time(nullptr));
    }

    std::string message;
    while (std::getline(ss, line)) {
        message += line + "\n";
    }
    if (!message.empty()) {
        message.pop_back();
    }
    commit.message = message;

    return commit;
}

std::string saveCommit(const CommitObject& commit) {
    std::stringstream commitContent;
    commitContent << "tree " << commit.tree_hash << "\n";
    
    for (const auto& parent : commit.parent_hashes) {
        commitContent << "parent " << parent << "\n";
    }
    
    std::time_t now = std::time(nullptr);
    commitContent << "author " << commit.author << " " << now << "\n";
    commitContent << "committer " << commit.committer << " " << now << "\n\n";
    
    commitContent << commit.message << "\n";
    
    std::string content = commitContent.str();
    std::string hash = computeHash(content);
    storeObject(hash, content);
    return hash;
}

std::string getHeadCommitHash() {
    std::ifstream headFile(".minigit/HEAD");
    if (!headFile.is_open()) return "";

    std::string headRef;
    std::getline(headFile, headRef);

    if (headRef.rfind("ref: ", 0) == 0) {
        std::string branchPath = headRef.substr(5);
        std::ifstream branchFile(".minigit/" + branchPath);
        if (!branchFile.is_open()) return "";
        std::string commitHash;
        std::getline(branchFile, commitHash);
        return commitHash;
    }
    return headRef;
}

std::string getBranchCommit(const std::string& branchName) {
    fs::path branchPath = ".minigit/refs/heads/" + branchName;
    std::ifstream branchFile(branchPath);
    if (!branchFile.is_open()) return "";
    std::string commitHash;
    std::getline(branchFile, commitHash);
    return commitHash;
}

void updateHead(const std::string& commitHash, const std::string& branchName = "") {
    if (branchName.empty()) {
        std::ofstream headFile(".minigit/HEAD", std::ios::trunc);
        headFile << commitHash << "\n";
    } else {
        fs::path branchPath = ".minigit/refs/heads/" + branchName;
        fs::create_directories(branchPath.parent_path());
        std::ofstream branchFile(branchPath, std::ios::trunc);
        branchFile << commitHash << "\n";

        std::ofstream headFile(".minigit/HEAD", std::ios::trunc);
        headFile << "ref: refs/heads/" << branchName << "\n";
        current_branch = branchName;
    }
}

bool branchExists(const std::string& branchName) {
    return fs::exists(".minigit/refs/heads/" + branchName);
}

void handleInit() {
    if (fs::exists(".minigit")) {
        std::cout << "Reinitialized existing MiniGit repository in " << fs::current_path() << "/.minigit" << std::endl;
        return;
    }

    fs::create_directories(".minigit/objects");
    fs::create_directories(".minigit/refs/heads");

    std::ofstream headFile(".minigit/HEAD");
    headFile << "ref: refs/heads/main\n";
    current_branch = "main";

    std::ofstream indexFile(".minigit/index");
    indexFile.close();

    std::cout << "Initialized empty MiniGit repository in " << fs::current_path() << "/.minigit" << std::endl;
}

void handleAdd(const std::vector<std::string>& files) {
    readIndex();
    for (const auto& filePathStr : files) {
        fs::path filePath = filePathStr;
        if (!fs::exists(filePath)) {
            std::cerr << "Error: file '" << filePath.string() << "' not found." << std::endl;
            continue;
        }
        if (fs::is_directory(filePath)) {
            for (const auto& entry : fs::recursive_directory_iterator(filePath)) {
                if (entry.is_regular_file()) {
                    std::string content = readFile(entry.path());
                    std::string hash = computeHash(content);
                    storeObject(hash, content);
                    staging_area[entry.path()] = hash;
                    std::cout << "Added: " << entry.path().string() << std::endl;
                }
            }
        } else {
            std::string content = readFile(filePath);
            std::string hash = computeHash(content);
            storeObject(hash, content);
            staging_area[filePath] = hash;
            std::cout << "Added: " << filePath.string() << std::endl;
        }
    }
    updateIndex();
}

void handleCommit(const std::string& message) {
    readIndex();

    if (staging_area.empty()) {
        std::cout << "Nothing to commit, working tree clean." << std::endl;
        return;
    }

    std::string treeHash = createTreeFromFiles(staging_area);
    std::string parentHash = getHeadCommitHash();

    CommitObject newCommit;
    newCommit.tree_hash = treeHash;
    newCommit.message = message;
    newCommit.author = "User <user@example.com>";
    newCommit.committer = "User <user@example.com>";
    newCommit.timestamp = std::to_string(std::time(nullptr));

    if (!parentHash.empty()) {
        newCommit.parent_hashes.push_back(parentHash);
    }

    std::string commitHash = saveCommit(newCommit);
    updateHead(commitHash, current_branch);

    staging_area.clear();
    updateIndex();

    std::cout << "[" << current_branch << " " << commitHash.substr(0, 7) << "] " << message << std::endl;
}

void handleLog() {
    std::string currentCommitHash = getHeadCommitHash();
    if (currentCommitHash.empty()) {
        std::cout << "No commits yet." << std::endl;
        return;
    }

    std::string commitToDisplay = currentCommitHash;
    while (!commitToDisplay.empty()) {
        CommitObject commit = parseCommitObject(commitToDisplay);
        std::cout << "commit " << commit.hash << std::endl;
        if (!commit.parent_hashes.empty() && commit.parent_hashes.size() > 1) {
            std::cout << "Merge: ";
            for (const auto& p : commit.parent_hashes) {
                std::cout << p.substr(0, 7) << " ";
            }
            std::cout << std::endl;
        }
        std::cout << "Author: " << commit.author << std::endl;
        std::time_t t;
        std::istringstream(commit.timestamp) >> t;
        std::string timeStr = std::ctime(&t);
        timeStr.pop_back();
        std::cout << "Date:    " << timeStr << std::endl;
        std::cout << "\n    " << commit.message << "\n\n";

        if (commit.parent_hashes.empty()) {
            commitToDisplay = "";
        } else {
            commitToDisplay = commit.parent_hashes[0];
        }
    }
}

void handleBranch(const std::string& branchName) {
    if (branchName.empty()) {
        std::cout << "Branches:\n";
        for (const auto& entry : fs::directory_iterator(".minigit/refs/heads")) {
            std::string name = entry.path().filename().string();
            std::cout << (name == current_branch ? "* " : "  ") << name << "\n";
        }
    } else {
        if (branchExists(branchName)) {
            std::cerr << "Error: Branch '" << branchName << "' already exists." << std::endl;
            return;
        }
        std::string currentCommitHash = getHeadCommitHash();
        if (currentCommitHash.empty()) {
            std::cerr << "Error: Cannot create branch, no commits yet." << std::endl;
            return;
        }
        fs::path branchPath = ".minigit/refs/heads/" + branchName;
        std::ofstream branchFile(branchPath);
        branchFile << currentCommitHash << "\n";
        std::cout << "Branch '" << branchName << "' created at " << currentCommitHash.substr(0, 7) << std::endl;
    }
}

void checkoutCommit(const std::string& commitHash) {
    CommitObject commit = parseCommitObject(commitHash);
    std::map<fs::path, std::string> filesInCommit = getTreeFiles(commit.tree_hash);

    cleanWorkingDirectory(getPaths(filesInCommit));
    restoreFiles(filesInCommit);

    staging_area = filesInCommit;
    updateIndex();

    updateHead(commitHash);
    current_branch = "(detached from " + commitHash.substr(0, 7) + ")";

    std::cout << "Checked out commit: " << commitHash.substr(0, 7) << std::endl;
}

void handleCheckout(const std::string& ref) {
    if (branchExists(ref)) {
        if (ref == current_branch) {
            std::cout << "Already on branch '" << ref << "'." << std::endl;
            return;
        }
        std::string branchCommitHash = getBranchCommit(ref);
        checkoutCommit(branchCommitHash);
        updateHead(branchCommitHash, ref);
        std::cout << "Switched to branch '" << ref << "'." << std::endl;
        return;
    }

    if (fs::exists(".minigit/objects/" + ref.substr(0, 2) + "/" + ref.substr(2))) {
        try {
            parseCommitObject(ref);
            checkoutCommit(ref);
            std::cout << "Note: You are in 'detached HEAD' state." << std::endl;
            return;
        } catch (const std::runtime_error& e) {
        }
    }

    std::cerr << "Error: Reference '" << ref << "' not found (neither branch nor commit)." << std::endl;
}

std::string findCommonAncestor(const std::string& commit1, const std::string& commit2) {
    // This is a simplified implementation. A true LCA needs to traverse up both histories.
    // For a more robust LCA, a bidirectional BFS from both commits or
    // storing commit depths would be more efficient.
    
    // For this simplified example, we'll assume a direct path or recent common ancestor
    // exists through parent hashes. This is a placeholder for a more complex graph traversal.

    std::unordered_set<std::string> visited1;
    std::queue<std::string> q1;
    q1.push(commit1);
    visited1.insert(commit1);

    while(!q1.empty()){
        std::string current = q1.front();
        q1.pop();
        CommitObject commit = parseCommitObject(current);
        for(const auto& parent : commit.parent_hashes){
            visited1.insert(parent);
            q1.push(parent);
        }
    }

    std::queue<std::string> q2;
    q2.push(commit2);

    while(!q2.empty()){
        std::string current = q2.front();
        q2.pop();
        if(visited1.count(current)){
            return current; // Found a common ancestor
        }
        CommitObject commit = parseCommitObject(current);
        for(const auto& parent : commit.parent_hashes){
            q2.push(parent);
        }
    }

    return ""; // No common ancestor found (should not happen in a valid repo history)
}

void handleMerge(const std::string& branchName) {
    if (!branchExists(branchName)) {
        std::cerr << "Error: Branch '" << branchName << "' does not exist." << std::endl;
        return;
    }

    std::string currentCommitHash = getHeadCommitHash();
    std::string branchCommitHash = getBranchCommit(branchName);

    if (currentCommitHash.empty()) {
        std::cerr << "Error: No commits on current branch to merge." << std::endl;
        return;
    }

    if (currentCommitHash == branchCommitHash) {
        std::cout << "Already up to date." << std::endl;
        return;
    }

    // Find the lowest common ancestor (LCA)
    std::string commonAncestorHash = findCommonAncestor(currentCommitHash, branchCommitHash);
    
    if (commonAncestorHash.empty()) {
        std::cerr << "Error: Could not find common ancestor." << std::endl;
        return;
    }

    // Get all files from LCA, current branch, and target branch
    std::map<fs::path, std::string> ancestorFiles = getTreeFiles(parseCommitObject(commonAncestorHash).tree_hash);
    std::map<fs::path, std::string> currentFiles = getTreeFiles(parseCommitObject(currentCommitHash).tree_hash);
    std::map<fs::path, std::string> branchFiles = getTreeFiles(parseCommitObject(branchCommitHash).tree_hash);

    // Merge changes
    std::set<fs::path> allFiles;
    for (const auto& [path, _] : ancestorFiles) allFiles.insert(path);
    for (const auto& [path, _] : currentFiles) allFiles.insert(path);
    for (const auto& [path, _] : branchFiles) allFiles.insert(path);

    bool hasConflict = false;
    std::map<fs::path, std::string> mergedFiles;

    for (const auto& filePath : allFiles) {
        std::string ancestorHash = ancestorFiles.count(filePath) ? ancestorFiles.at(filePath) : "";
        std::string currentHash = currentFiles.count(filePath) ? currentFiles.at(filePath) : "";
        std::string branchHash = branchFiles.count(filePath) ? branchFiles.at(filePath) : "";

        if (ancestorHash == currentHash && ancestorHash == branchHash) {
            // No changes
            mergedFiles[filePath] = currentHash;
        } else if (ancestorHash == currentHash && ancestorHash != branchHash) {
            // Changed in branch, not in current
            mergedFiles[filePath] = branchHash;
        } else if (ancestorHash != currentHash && ancestorHash == branchHash) {
            // Changed in current, not in branch
            mergedFiles[filePath] = currentHash;
        } else if (currentHash == branchHash) {
            // Same change in both
            mergedFiles[filePath] = currentHash;
        } else {
            // Conflict: changed differently in both
            std::cerr << "CONFLICT: Both modified " << filePath.string() << std::endl;
            hasConflict = true;
            // For simplicity, we'll take the current version.
            // A real Git merge would write conflict markers to the file.
            mergedFiles[filePath] = currentHash; 
        }
    }

    if (hasConflict) {
        std::cerr << "Merge failed - fix conflicts and commit the result." << std::endl;
        // Do not create a commit, leave files in conflicted state (simple version)
        // A more advanced version would write conflict markers to files in the working directory
        // and update the index with conflict entries.
        cleanWorkingDirectory(getPaths(mergedFiles)); // Restore to merged state (with current version for conflicts)
        restoreFiles(mergedFiles);
        staging_area = mergedFiles; // Add merged files to staging (including "resolved" conflicts)
        updateIndex();
        return;
    }

    // Create a merge commit
    CommitObject newCommit;
    newCommit.tree_hash = createTreeFromFiles(mergedFiles);
    newCommit.message = "Merge branch '" + branchName + "' into " + current_branch;
    newCommit.author = "User <user@example.com>";
    newCommit.committer = "User <user@example.com>";
    newCommit.parent_hashes.push_back(currentCommitHash);
    newCommit.parent_hashes.push_back(branchCommitHash);

    std::string commitHash = saveCommit(newCommit);
    updateHead(commitHash, current_branch);

    // Update working directory
    cleanWorkingDirectory(getPaths(mergedFiles));
    restoreFiles(mergedFiles);

    staging_area = mergedFiles; // Update staging area to reflect the merge
    updateIndex();

    std::cout << "Successfully merged '" << branchName << "' into '" << current_branch << "'." << std::endl;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <command> [args...]" << std::endl;
        return 1;
    }

    std::vector<std::string> args;
    for (int i = 1; i < argc; ++i) {
        args.push_back(argv[i]);
    }

    std::string command = args[0];

    try {
        if (command == "init") {
            handleInit();
        } else if (command == "add") {
            if (args.size() < 2) {
                std::cerr << "Usage: minigit add <file1> [file2...]" << std::endl;
                return 1;
            }
            std::vector<std::string> files(args.begin() + 1, args.end());
            handleAdd(files);
        } else if (command == "commit") {
            if (args.size() != 3 || args[1] != "-m") {
                std::cerr << "Usage: minigit commit -m \"<message>\"" << std::endl;
                return 1;
            }
            handleCommit(args[2]);
        } else if (command == "log") {
            handleLog();
        } else if (command == "branch") {
            if (args.size() == 1) {
                handleBranch("");
            } else if (args.size() == 2) {
                handleBranch(args[1]);
            } else {
                std::cerr << "Usage: minigit branch OR minigit branch <name>" << std::endl;
                return 1;
            }
        } else if (command == "checkout") {
            if (args.size() != 2) {
                std::cerr << "Usage: minigit checkout <branch_name_or_commit_hash>" << std::endl;
                return 1;
            }
            handleCheckout(args[1]);
        } else if (command == "merge") { // Added merge command handler
            if (args.size() != 2) {
                std::cerr << "Usage: minigit merge <branch_name>" << std::endl;
                return 1;
            }
            handleMerge(args[1]);
        } 
        else {
            std::cerr << "Unknown command: " << command << std::endl;
            std::cerr << "Available commands: init, add, commit, log, branch, checkout, merge" << std::endl;
            return 1;
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
